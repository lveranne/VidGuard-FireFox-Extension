// ─── VidGuard Background Script (Firefox MV2) ────────────────────────────────
// Firefox uses browser.* (Promise-based) instead of chrome.* (callback-based).
// The webextension-polyfill (browser-polyfill.js) bridges this gap so the
// same logic works in both. This file uses the native browser.* API directly
// since it runs in Firefox only.

const API_BASE    = "https://extensionbackend-435925497959.us-central1.run.app";
const FRAME_COUNT = 10;
const WEB_APP     = "https://vidguard-frontend-435925497959.us-central1.run.app";

// Firefox MV2 background scripts use browser.runtime.onMessage which returns
// a Promise instead of using sendResponse. We need to return a true Promise.
browser.runtime.onMessage.addListener((message) => {

  if (message.type === "ANALYZE_IMAGE") {
    return analyzeImage(message.payload)
      .then((result) => ({ ok: true, result }))
      .catch((err)   => ({ ok: false, error: err.message }));
  }

  if (message.type === "GET_SETTINGS") {
    return browser.storage.sync.get({ showOnFake: false })
      .then((settings) => ({ ok: true, settings }));
  }

  if (message.type === "SAVE_SETTINGS") {
    return browser.storage.sync.set(message.payload)
      .then(() => ({ ok: true }));
  }
});

async function analyzeImage({ dataUrl }) {
  const fetchRes = await fetch(dataUrl);
  const blob     = await fetchRes.blob();

  const form = new FormData();
  form.append("image", blob, "frame.jpg");
  form.append("end_frame", String(FRAME_COUNT));

  const res = await fetch(`${API_BASE}/api/predict-image`, {
    method: "POST",
    body: form,
  });

  return parseResponse(res);
}

async function parseResponse(res) {
  let data;
  try { data = await res.json(); }
  catch { throw new Error(`Invalid response (${res.status})`); }

  if (!res.ok) throw new Error(data.error ?? `API error (${res.status})`);
  if (data.label === "UNKNOWN") throw new Error(data.error ?? "No face detected");

  return {
    verdict   : data.label === "REAL" ? "authentic" : "deepfake",
    confidence: Math.round(data.confidence * 10) / 10,
    webAppUrl : data.web_app_url ?? WEB_APP,
  };
}
