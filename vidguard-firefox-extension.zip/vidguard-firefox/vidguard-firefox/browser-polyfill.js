// ─── Minimal chrome → browser polyfill for Firefox ───────────────────────────
// Firefox exposes window.browser natively. Chrome does not.
// This shim makes chrome.* work in Firefox content scripts and popups
// by aliasing window.chrome to window.browser where missing.
// For full production use, replace with the official Mozilla webextension-polyfill:
// https://github.com/mozilla/webextension-polyfill

(function () {
  if (typeof globalThis.browser !== "undefined" && typeof globalThis.chrome === "undefined") {
    globalThis.chrome = globalThis.browser;
  }
  // Firefox's browser.tabs.sendMessage is Promise-based; wrap it so our
  // callback-style popup.js calls still work.
  if (typeof globalThis.browser !== "undefined") {
    const _sendMessage = globalThis.chrome.tabs.sendMessage.bind(globalThis.chrome.tabs);
    globalThis.chrome.tabs.sendMessage = function (tabId, msg, callback) {
      if (callback) {
        browser.tabs.sendMessage(tabId, msg).then(callback).catch(() => callback(null));
      } else {
        return browser.tabs.sendMessage(tabId, msg);
      }
    };

    const _rtSend = globalThis.chrome.runtime.sendMessage.bind(globalThis.chrome.runtime);
    globalThis.chrome.runtime.sendMessage = function (msg, callback) {
      if (callback) {
        browser.runtime.sendMessage(msg).then(callback).catch(() => callback(null));
      } else {
        return browser.runtime.sendMessage(msg);
      }
    };
  }
})();
