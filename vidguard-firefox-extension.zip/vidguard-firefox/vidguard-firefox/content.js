// ─── VidGuard Content Script ──────────────────────────────────────────────────
// Lightweight receiver: the popup asks for a frame, we capture it and reply.
// No overlay is injected into the page anymore.

(function () {
  "use strict";

  // Track src changes so the popup knows when the video changed
  let lastVideoKey = null;

  function getActiveVideo() {
    // Find the largest visible video on the page
    let best = null;
    let bestArea = 0;
    document.querySelectorAll("video").forEach((v) => {
      const r = v.getBoundingClientRect();
      const area = r.width * r.height;
      if (area > bestArea && r.width > 100 && r.height > 100) {
        bestArea = area;
        best = v;
      }
    });
    return best;
  }

  function getVideoKey(video) {
    return video ? (video.currentSrc || video.src || null) : null;
  }

  function captureFrame(video) {
    try {
      const w = video.videoWidth  || 640;
      const h = video.videoHeight || 360;
      const canvas = document.createElement("canvas");
      canvas.width = w; canvas.height = h;
      canvas.getContext("2d").drawImage(video, 0, 0, w, h);
      return canvas.toDataURL("image/jpeg", 0.92);
    } catch { return null; }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "CAPTURE_FRAME") {
      const video = getActiveVideo();
      if (!video) {
        sendResponse({ ok: false, error: "No video found on this page" });
        return true;
      }
      const key    = getVideoKey(video);
      const dataUrl = captureFrame(video);
      if (!dataUrl) {
        sendResponse({ ok: false, error: "Could not capture frame" });
        return true;
      }
      lastVideoKey = key;
      sendResponse({ ok: true, dataUrl, videoKey: key });
      return true;
    }

    if (msg.type === "GET_VIDEO_KEY") {
      const video = getActiveVideo();
      sendResponse({ videoKey: getVideoKey(video) });
      return true;
    }
  });

})();
