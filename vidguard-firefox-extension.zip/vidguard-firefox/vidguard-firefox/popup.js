// ─── VidGuard Popup Script ────────────────────────────────────────────────────

const $ = (id) => document.getElementById(id);

// ── State machine ─────────────────────────────────────────────────────────────

const STATES = ["idle", "loading", "result", "error"];

function setState(name) {
  STATES.forEach((s) => {
    const el = $(`state-${s}`);
    if (el) el.classList.toggle("visible", s === name);
  });
}

// ── Active tab helpers ────────────────────────────────────────────────────────

function getActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => resolve(tab));
  });
}

function sendToTab(tabId, msg) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, msg, (res) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(res);
    });
  });
}

function sendToBackground(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, (res) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(res);
    });
  });
}

// ── Platform detection ────────────────────────────────────────────────────────

let currentTabId    = null;
let currentPlatform = null;

(async () => {
  const tab = await getActiveTab();
  if (!tab) return;
  currentTabId = tab.id;

  const url = tab.url ?? "";
  currentPlatform =
    url.includes("tiktok.com")    ? "tiktok"    :
    url.includes("youtube.com")   ? "youtube"   :
    url.includes("instagram.com") ? "instagram" : null;

  if (currentPlatform) {
    $(`plat-${currentPlatform}`).classList.add("active");
    $("scan-hint").textContent = "Click Scan to analyse the current video.";
  } else {
    $("status-dot").classList.add("inactive");
    $("scan-btn").disabled = true;
    $("scan-hint").textContent = "Navigate to TikTok, YouTube Shorts, or Instagram Reels first.";
  }
})();

// ── Load settings ─────────────────────────────────────────────────────────────

chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, ({ ok, settings }) => {
  if (!ok) return;
  $("show-on-fake").checked = settings.showOnFake ?? false;
});

// ── Scan ──────────────────────────────────────────────────────────────────────

async function runScan() {
  if (!currentTabId) return;
  setState("loading");

  try {
    // 1. Ask content script to capture the current video frame
    const capture = await sendToTab(currentTabId, { type: "CAPTURE_FRAME" });
    if (!capture?.ok) throw new Error(capture?.error ?? "No video found on this page");

    // 2. Send frame to background → API
    const res = await sendToBackground({
      type: "ANALYZE_IMAGE",
      payload: { dataUrl: capture.dataUrl },
    });
    if (!res.ok) throw new Error(res.error);

    showResult(res.result);

  } catch (err) {
    showError(friendlyError(err.message));
  }
}

function friendlyError(msg) {
  if (!msg) return "Scan failed — try again.";
  const m = msg.toLowerCase();
  if (m.includes("no video") || m.includes("found"))   return "No video detected on this page.";
  if (m.includes("face") || m.includes("unknown"))     return "No face found in this frame. Try pausing on a clearer face.";
  if (m.includes("network") || m.includes("fetch") || m.includes("api")) return "Cannot reach VidGuard server. Is it running?";
  if (m.includes("capture"))                           return "Could not capture the video frame.";
  return msg.slice(0, 80);
}

// ── Show result ───────────────────────────────────────────────────────────────

function showResult(result) {
  const isDeepfake = result.verdict === "deepfake";

  // Card colour
  const card = $("result-card");
  card.className = "result-card " + result.verdict;

  // Icon
  $("verdict-icon").innerHTML = isDeepfake ? iconWarning() : iconShield();

  // Label + confidence
  $("verdict-label").textContent = isDeepfake ? "DEEPFAKE" : "AUTHENTIC";
  $("verdict-conf").textContent  = result.confidence.toFixed(0) + "%";

  // If "show on fake only" and video is authentic, go back to idle silently
  const showOnFake = $("show-on-fake").checked;
  if (showOnFake && !isDeepfake) {
    setState("idle");
    return;
  }

  setState("result");
}

function showError(msg) {
  $("error-text").textContent = msg;
  setState("error");
}

// ── Icons ─────────────────────────────────────────────────────────────────────

function iconWarning() {
  return `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#f87171" stroke-width="2.2">
    <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
    <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
  </svg>`;
}
function iconShield() {
  return `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2.2">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    <polyline points="9 12 11 14 15 10"/>
  </svg>`;
}

// ── Button wiring ─────────────────────────────────────────────────────────────

$("scan-btn").addEventListener("click",  runScan);
$("btn-retry").addEventListener("click", runScan);
$("btn-rescan").addEventListener("click", () => { setState("idle"); });

// ── Save settings ─────────────────────────────────────────────────────────────

$("save-btn").addEventListener("click", () => {
  chrome.runtime.sendMessage({
    type: "SAVE_SETTINGS",
    payload: { showOnFake: $("show-on-fake").checked },
  }, () => {
    const msg = $("saved-msg");
    msg.style.display = "block";
    setTimeout(() => { msg.style.display = "none"; }, 1800);
  });
});
